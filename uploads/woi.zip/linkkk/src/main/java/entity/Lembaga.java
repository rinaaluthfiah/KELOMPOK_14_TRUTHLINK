/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author USER
 */
import jakarta.persistence.*;

@Entity
@Table(name = "lembaga")
public class Lembaga {

    @Id
    private String id_lembaga;

    private String nama_lembaga;
    private String alamat;
    private String kontak;

    @Enumerated(EnumType.STRING)
    private JenisLembaga jenis_lembaga;

    // Relasi ke User — satu Lembaga terhubung ke satu User yang mendaftarkannya
    @ManyToOne
    @JoinColumn(name = "id_user")
    private User user;

    // Enum untuk jenis Lembaga
    public enum JenisLembaga {
        Penegak_Hukum,
        Anti_Korupsi_Pengawasan,
        Perlindungan_Kekerasan,
        Etika_Transparansi
    }

    public Lembaga() {}

    public Lembaga(String id_lembaga, String nama_lembaga, String alamat, String kontak,
                   JenisLembaga jenis_lembaga, User user) {
        this.id_lembaga = id_lembaga;
        this.nama_lembaga = nama_lembaga;
        this.alamat = alamat;
        this.kontak = kontak;
        this.jenis_lembaga = jenis_lembaga;
        this.user = user;
    }

    // Getter & Setter
    public String getId_lembaga() {
        return id_lembaga;
    }

    public void setId_lembaga(String id_lembaga) {
        this.id_lembaga = id_lembaga;
    }

    public String getNama_lembaga() {
        return nama_lembaga;
    }

    public void setNama_lembaga(String nama_lembaga) {
        this.nama_lembaga = nama_lembaga;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getKontak() {
        return kontak;
    }

    public void setKontak(String kontak) {
        this.kontak = kontak;
    }

    public JenisLembaga getJenis_lembaga() {
        return jenis_lembaga;
    }

    public void setJenis_lembaga(JenisLembaga jenis_lembaga) {
        this.jenis_lembaga = jenis_lembaga;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
