/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author USER
 */

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "laporan")
public class Laporan {

    @Id
    private String id_laporan;

    private String judul_laporan;
    private String isi_laporan;

    @Temporal(TemporalType.TIMESTAMP)
    private Date tanggal_laporan;

    private String status; // contoh: "Menunggu", "Diproses", "Selesai"

    // Relasi ke Pelapor
    @ManyToOne
    @JoinColumn(name = "id_user") // kolom foreign key di tabel Laporan
    private Pelapor pelapor;

    public Laporan() {}

    public Laporan(String id_laporan, String judul_laporan, String isi_laporan, Date tanggal_laporan, String status, Pelapor pelapor) {
        this.id_laporan = id_laporan;
        this.judul_laporan = judul_laporan;
        this.isi_laporan = isi_laporan;
        this.tanggal_laporan = tanggal_laporan;
        this.status = status;
        this.pelapor = pelapor;
    }

    // Getter dan Setter
    public String getId_laporan() {
        return id_laporan;
    }

    public void setId_laporan(String id_laporan) {
        this.id_laporan = id_laporan;
    }

    public String getJudul_laporan() {
        return judul_laporan;
    }

    public void setJudul_laporan(String judul_laporan) {
        this.judul_laporan = judul_laporan;
    }

    public String getIsi_laporan() {
        return isi_laporan;
    }

    public void setIsi_laporan(String isi_laporan) {
        this.isi_laporan = isi_laporan;
    }

    public Date getTanggal_laporan() {
        return tanggal_laporan;
    }

    public void setTanggal_laporan(Date tanggal_laporan) {
        this.tanggal_laporan = tanggal_laporan;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Pelapor getPelapor() {
        return pelapor;
    }

    public void setPelapor(Pelapor pelapor) {
        this.pelapor = pelapor;
    }
}
