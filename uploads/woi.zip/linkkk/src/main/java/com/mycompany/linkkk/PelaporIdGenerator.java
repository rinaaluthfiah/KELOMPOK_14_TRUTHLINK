package com.mycompany.linkkk;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class PelaporIdGenerator implements IdentifierGenerator {

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) {
        String prefix = "PLP";

        Session hibernateSession = (Session) session;
        List<String> ids = hibernateSession.createQuery(
                "SELECT u.id_user FROM User u ORDER BY u.id_user DESC", String.class)
                .setMaxResults(1)
                .getResultList();

        int nextId = 1;
        if (!ids.isEmpty()) {
            String lastId = ids.get(0);
            String numericPart = lastId.substring(3); // ambil 000001
            nextId = Integer.parseInt(numericPart) + 1;
        }

        return prefix + new DecimalFormat("00000").format(nextId);
    }
}
