package com.mycompany.linkkk;

import com.mycompany.linkkk.HibernateUtil;
import org.hibernate.Session;

public class Linkkk {
    public static void main(String[] args) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            System.out.println("✅ Koneksi Hibernate berhasil!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
