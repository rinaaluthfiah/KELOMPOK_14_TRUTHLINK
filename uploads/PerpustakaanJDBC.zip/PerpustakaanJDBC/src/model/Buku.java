/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author acer
 */
public class Buku implements CRUD{
    private int idBuku;
    private String namaBuku;
    private String namaPenulis;
    private int jumlahHalaman;
    
    public Buku(String namaBuku, String namaPenulis, int jumlahHalaman){
        this.namaBuku = namaBuku;
        this.namaPenulis = namaPenulis;
        this.jumlahHalaman = jumlahHalaman;
    }

    public int getIdBuku() {
        return idBuku;
    }

    public String getNamaBuku() {
        return namaBuku;
    }

    public void setNamaBuku(String namaBuku) {
        this.namaBuku = namaBuku;
    }

    public String getNamaPenulis() {
        return namaPenulis;
    }

    public void setNamaPenulis(String namaPenulis) {
        this.namaPenulis = namaPenulis;
    }

    public int getJumlahHalaman() {
        return jumlahHalaman;
    }

    public void setJumlahHalaman(int jumlahHalaman) {
        this.jumlahHalaman = jumlahHalaman;
    }

    @Override
    public void create() {
        System.out.println("Create");
    }

    @Override
    public void read() {
        System.out.println("Read");
    }

    @Override
    public void update(int id) {
        System.out.println("Update");
    }

    @Override
    public void delete(int id) {
        System.out.println("Delete");
    }
    
}
